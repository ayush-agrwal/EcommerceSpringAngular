import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../_services/product.service';
import { ImageProcessingService } from '../image-processing.service';
import { Product } from '../_model/product.model';
import { map } from 'rxjs';
@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.css'
})
export class ViewDetailsComponent {
  productId: string | null = null;
  userId: string | null = null;

  constructor(private route: ActivatedRoute,
    private productService: ProductService,
    private imageProcessingService: ImageProcessingService,
    private router:Router
    
  ) {}

  product:Product;

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.productId = params.get('productId');
      if (this.productId) {
        this.productService.getProductById(parseInt(this.productId, 10)).pipe(
          map((product: Product) => this.imageProcessingService.createImage(product))
        ).subscribe(
          (resp: Product) => {
            this.product = resp;
            console.log(this.product);
          },
          (err) => {
            console.log('Error in fetching product by ID');
          }
        );
      }
    });
  }


public buyProduct(productId){

this.router.navigate(['/buyProduct',{
  isSingleProductCheckout:true,
  id: productId
}]);

}
}
  