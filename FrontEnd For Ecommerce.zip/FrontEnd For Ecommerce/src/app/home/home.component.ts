import { Component } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { catchError, map, takeUntil } from 'rxjs/operators';
import { Product } from '../_model/product.model';
import { ImageProcessingService } from '../image-processing.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Subject } from 'rxjs/internal/Subject';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  private unsubscribe$ = new Subject<void>();
  constructor(private productService:ProductService,
    private imageProcessingService: ImageProcessingService,
    private sanitizer: DomSanitizer,
  ){

  }
  ngOnInit():void{
    //alert(" i am, called");
    this.getAllProduct();
  
  }
  products: Product[] = [];

  public getAllProduct() {
    this.productService.getAllProduct().pipe(
      map((products: Product[]) => {
        return products.map((product: Product) => {
          this.imageProcessingService.createImage(product);
          return product;
        });
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error fetching products:', error);
        return [];
      }),
      takeUntil(this.unsubscribe$)
    ).subscribe({
      next: (resp: Product[]) => {
        this.products = resp;
      },
      error: (error: HttpErrorResponse) => {
        console.error('Subscription error:', error);
      }
    });
  }

}
