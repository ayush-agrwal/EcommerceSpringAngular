import { Component, OnInit } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Product } from '../_model/product.model';
import { DomSanitizer } from '@angular/platform-browser';
import { ImageProcessingService } from '../image-processing.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-show-product-details',
  templateUrl: './show-product-details.component.html',
  styleUrls: ['./show-product-details.component.css']
})
export class ShowProductDetailsComponent implements OnInit {
  products: Product[] = [];
  error: any;

  dialogVisible = false;
  selectedProduct: Product | null = null;

  constructor(
    private productService: ProductService,
    private sanitizer: DomSanitizer,
    private imageProcessingService: ImageProcessingService
  ) {}

  ngOnInit(): void {
    this.getAllProduct();
  }

  public getAllProduct() {
    this.productService.getAllProduct().pipe(
      map((products: Product[]) => 
        products.map((product: Product) => this.imageProcessingService.createImage(product))
      )
    ).subscribe(
      (resp: Product[]) => {
        this.products = resp;
      },
      (error: HttpErrorResponse) => {
        console.log(error);
      }
    );
  }

  public openDialog(product: Product): void {
    this.selectedProduct = product;
    console.log("this is selected product");
    console.log(this.selectedProduct);
    this.dialogVisible = true;
  }

  closeDialog(): void {
    this.dialogVisible = false;
    this.selectedProduct = null;
  }

  public getProd() {
    console.log(this.products);
  }
}
