import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../_model/product.model';
import { Observable } from 'rxjs';
import { OrderDetails } from '../_model/order-details.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(
    private httpClient:HttpClient
  ) { }
  private baseUrl = 'http://localhost:8080'; 
  public addProduct(product:FormData){
    return this.httpClient.post<Product>("http://localhost:8080/addNewProduct",product);
  }

  public getAllProduct(){

    return this.httpClient.get<Product[]>("http://localhost:8080/getAllProducts");
  }

  getProductById(productId: number): Observable<Product> {
    return this.httpClient.get<Product>(`${this.baseUrl}/getProductById/${productId}`);
  }

  public getProductDetails(isSingleCheckout,productId){

  return this.httpClient.get<Product[]>("http://localhost:8080/getProductDetails/"+isSingleCheckout+"/"+productId);
  }

  public placeOrder(orderDetails:OrderDetails){
    return this.httpClient.post("http://localhost:8080/placeOrder", orderDetails)
  }
}
