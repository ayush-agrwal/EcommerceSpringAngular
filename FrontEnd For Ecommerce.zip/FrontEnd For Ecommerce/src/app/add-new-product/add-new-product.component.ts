import { Component } from '@angular/core';
import { Product } from '../_model/product.model';
import { NgForm } from '@angular/forms';
import { ProductService } from '../_services/product.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FileHandle } from '../_model/file-handle.model';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrl: './add-new-product.component.css'
})
export class AddNewProductComponent {

  constructor(private productService:ProductService,
    private sanitizer:DomSanitizer
  ){

  }

  product:Product={
    productId:0,
    productName:"",
    productDescription:"",
    productDiscount:0,
    productActualPrice:0,
    productImages:[]
  }

  
  addProduct(productForm: NgForm) {
    const productformdata =this.prepareFormData(this.product);
    console.log(productForm.value);
    this.productService.addProduct(productformdata).subscribe({
      next: (response: Product) => {
        console.log(response);
      },
      error: (error: HttpErrorResponse) => {
        console.log(error);
      }
    });

    alert("product saved successfully");
    this.resetForm(productForm);
    
  }

  resetForm(productForm: NgForm) {
    productForm.resetForm();
    this.product = {
      productId:0,
      productName: "",
      productDescription: "",
      productDiscount: 0,
      productActualPrice: 0,
      productImages: []
    };
  }

  prepareFormData(product:Product):FormData{

    const formdata=new FormData();
    formdata.append(
      'product',
      new Blob([JSON.stringify(product)],{type:'application/json'})
    );
    
    for(var i=0; i<product.productImages.length;i++){

      formdata.append(
        'imageFile',
        product.productImages[i].file,
        product.productImages[i].file.name
      );
    }

    return formdata;
  }
  onFileSelected(event:any){

    alert(" iam called ");

    if(event.target.files){
      const file= event.target.files[0];

       const fileHandle:FileHandle={

        file:file,
        url: this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(file))
       }

       this.product.productImages.push(fileHandle);

       



    }
  }
}
