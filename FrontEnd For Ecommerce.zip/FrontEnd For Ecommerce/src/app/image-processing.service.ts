import { Injectable } from '@angular/core';
import { Product } from './_model/product.model';
import { FileHandle } from './_model/file-handle.model';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class ImageProcessingService {

  constructor(private sanitizer: DomSanitizer) { }

  public createImage(product: Product): Product {
    const productImages: any[] = product.productImages;
    const productImagesToFileHandle: FileHandle[] = [];

    for (let i = 0; i < productImages.length; i++) {
      const imageFileData = productImages[i];
      try {
        const cleanedBase64 = this.cleanBase64String(imageFileData.picByte);
        const imageBlob = this.dataURLtoBlob(cleanedBase64, imageFileData.type);
        const imageFile = new File([imageBlob], imageFileData.name, { type: imageFileData.type });

        const fileHandle: FileHandle = {
          file: imageFile,
          url: this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(imageFile))
        };

        productImagesToFileHandle.push(fileHandle);
      } catch (error) {
        console.error('Failed to convert image data to Blob:', error, imageFileData.picByte);
      }
    }

    product.productImages = productImagesToFileHandle;
    return product;
  }

  private dataURLtoBlob(picByte: string, imageType: string): Blob {
    // Validate base64 string
    if (!this.isValidBase64(picByte)) {
      throw new Error('Invalid base64 string');
    }

    const byteString = window.atob(picByte);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const intArray = new Uint8Array(arrayBuffer);

    for (let i = 0; i < byteString.length; i++) {
      intArray[i] = byteString.charCodeAt(i);
    }

    return new Blob([intArray], { type: imageType });
  }

  private cleanBase64String(base64: string): string {
    // Remove any whitespaces or line breaks from the base64 string
    return base64.replace(/\s/g, '');
  }

  private isValidBase64(str: string): boolean {
    // Check if the base64 string is valid
    const base64Regex = /^(?:[A-Za-z0-9+/]{4})*?(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
    return base64Regex.test(str);
  }
}
