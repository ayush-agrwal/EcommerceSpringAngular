import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { UserAuthService } from '../_services/user-auth.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private userAuthService: UserAuthService, private router: Router) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // If the request has a No-Auth header, let it pass without modification
    if (req.headers.get('No-Auth') === 'True') {
      return next.handle(req.clone());
    }

    // Retrieve the token from the UserAuthService
    const token = this.userAuthService.getToken();

    // If the token is available, add it to the request
    if (token) {
      req = this.addToken(req, token);
    }

    // Handle the request and catch any errors
    return next.handle(req).pipe(
      catchError((err: HttpErrorResponse) => {
        console.log(err.status);

        // If the error status is 401 (Unauthorized), navigate to the login page
        if (err.status === 401) {
          this.router.navigate(['/login']);
        } 
        // If the error status is 403 (Forbidden), navigate to the forbidden page
        else if (err.status === 403) {
          this.router.navigate(['/forbidden']);
        }

        // Throw a new error with a custom message
        return throwError(() => new Error('An error occurred while processing the request.'));
      })
    );
  }

  // Method to clone the request and add the Authorization header
  private addToken(request: HttpRequest<any>, token: string): HttpRequest<any> {
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }
}
