export interface OrderQuantity{

    productId:number;
    quantity:number;
}