import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowPruoductToUserComponent } from './show-pruoduct-to-user.component';

describe('ShowPruoductToUserComponent', () => {
  let component: ShowPruoductToUserComponent;
  let fixture: ComponentFixture<ShowPruoductToUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ShowPruoductToUserComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ShowPruoductToUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
