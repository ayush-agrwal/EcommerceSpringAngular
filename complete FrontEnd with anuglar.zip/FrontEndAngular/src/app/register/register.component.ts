import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../_services/user.service';
import { response } from 'express';
import { error } from 'console';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {


  constructor(private userSerivce:UserService,
    private router:Router
  ){

  }

  public register(registerForm:NgForm){


    //alert("i am called")

    console.log(registerForm.value);
    this.userSerivce.register(registerForm.value).subscribe(

      (response)=>{
        
        //console.log(response);
        
        this.router.navigate(['/login'])
      },
      (error)=>{
        console.log(error);


      }
    );
  }
}
