import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../_services/product.service';
import { ImageProcessingService } from '../image-processing.service';
import { Product } from '../_model/product.model';
import { map } from 'rxjs';
import { response } from 'express';
import { error } from 'console';
@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.css'
})
export class ViewDetailsComponent {
  productId: string | null = null;
  userId: string | null = null;

  constructor(private route: ActivatedRoute,
    private productService: ProductService,
    private imageProcessingService: ImageProcessingService,
    private router:Router
    
  ) {}

  product:Product;

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.productId = params.get('productId');
      if (this.productId) {
        this.productService.getProductById(parseInt(this.productId, 10)).pipe(
          map((product: Product) => this.imageProcessingService.createImage(product))
        ).subscribe(
          (resp: Product) => {
            this.product = resp;
            console.log(this.product);
          },
          (err) => {
            console.log('Error in fetching product by ID');
          }
        );
      }
    });
  }


public buyProduct(productId){

this.router.navigate(['/buyProduct',{
  isSingleProductCheckout:true,
  id: productId
}]);

}

public AddToCart(productId){

  //console.log(" this isbs sbjdb");
  //console.log(productId);
  this.productService.addToCart(productId).subscribe(

    (response)=>{
      console.log(response);
      this.router.navigate(['/cart']);
    },
    (error)=>{
      console.log(error);
    }
  )
  
}
}
  