import { Component,OnInit  } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { response } from 'express';
import { error } from 'console';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-all-orders',
  templateUrl: './show-all-orders.component.html',
  styleUrl: './show-all-orders.component.css'
})
export class ShowAllOrdersComponent {

  allOrders:any=[];
  constructor(private productSerice:ProductService,
    private router:Router
  ){

    this.getAllOrder();

  }

  productDelivererd(orderId){

   console.log("orderid "+orderId);
   this.productSerice.deliveredOrder(orderId).subscribe(
    (response)=>{
      console.log(response);
      this.router.navigate(['/showAllOrder']);
    }
    ,
    (error)=>{
      console.log(error);
    }
   )
  }
  getAllOrder(){

    this.productSerice.getAllPlacedOrder().subscribe(
      (response)=>{
        console.log(response);
        this.allOrders=response;

        

      },
      (error)=>{
        console.log(error);
      }
    )
  }


}
