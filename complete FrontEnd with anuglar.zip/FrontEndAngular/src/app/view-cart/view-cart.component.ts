import { Component,OnInit  } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { Router } from '@angular/router';
import { response } from 'express';
import { error } from 'console';

@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrl: './view-cart.component.css'
})
export class ViewCartComponent {

  cartDetails:any=[];

  ngOnInit():void{

   this.getCartDetails();
  }
  constructor(private productService:ProductService,
    private router:Router
  ){

  }

  


  getCartDetails(){

    this.productService.getCartDetails().subscribe(
      (response)=>{
       
        

     console.log(response);

     this.cartDetails=response;
        
      }

      ,
      (error)=>{

        console.log(error);
      }

    );
  }

  checkout(){

    /*this.productService.getProductDetails(false, 0).subscribe(

      (response)=>{

        console.log(response);

      },
      (error)=>{
        console.log(error);
      }
    );
  }*/
    this.router.navigate(['/buyProduct',{
      isSingleProductCheckout:false,
      id: 0
    }]);
    


  }

  deleteItem(cart:any){

    console.log(cart.cartId);

    this.productService.deleteCartitem(cart.cartId).subscribe(
      (response)=>{

        console.log(response)
        this.getCartDetails();
      },
      (error)=>{
        console.log(error);
      }
    );
  }
}
