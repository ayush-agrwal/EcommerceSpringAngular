import { Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ProductService } from '../_services/product.service';
import { ImageProcessingService } from '../image-processing.service';
import { HttpErrorResponse } from '@angular/common/http';
import { map } from 'rxjs';
import { Product } from '../_model/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-pruoduct-to-user',
  templateUrl: './show-pruoduct-to-user.component.html',
  styleUrl: './show-pruoduct-to-user.component.css'
})
export class ShowPruoductToUserComponent {
  constructor(
    private productService: ProductService,
    private sanitizer: DomSanitizer,
    private imageProcessingService: ImageProcessingService,
    private router:Router
  ) {}

  products: Product[] = [];
  error: any;
  ngOnInit(): void {
    this.getAllProduct();
    
  }

  public getAllProduct() {
    this.productService.getAllProduct().pipe(
      map((products: Product[]) => 
        products.map((product: Product) => this.imageProcessingService.createImage(product))
      )
    ).subscribe(
      (resp: Product[]) => {
        this.products = resp;
      },
      (error: HttpErrorResponse) => {
        console.log(error);
      }
    );
  }

  ViewDetail(productId){

    this.router.navigate(['/viewDetails',{productId:productId}])
 

  }
}


/*

this.productService.getProductById(3).subscribe(

      (resp :any)=>{
        console.log(resp);
      }
      ,
      (err)=>
      {
        console.log(err);
      }
    )

*/