import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { authGuard } from './_auth/auth.guard';
import { AddNewProductComponent } from './add-new-product/add-new-product.component';
import { ShowProductDetailsComponent } from './show-product-details/show-product-details.component';
import { ShowPruoductToUserComponent } from './show-pruoduct-to-user/show-pruoduct-to-user.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { BuyProductComponent } from './buy-product/buy-product.component';
import { BuyProductResolveService } from './buy-product-resolve.service';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';
import { RegisterComponent } from './register/register.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { MyordersComponent } from './myorders/myorders.component';
import { ShowAllOrdersComponent } from './show-all-orders/show-all-orders.component';

const routes: Routes = [


  { path: 'viewDetails', component: ViewDetailsComponent },
  {
    path: 'buyProduct', component: BuyProductComponent,
    canActivate: [authGuard],
    data: { roles: ['User'] },
    resolve: {
      product: BuyProductResolveService
    }
  },


  { path: 'showProductDetails', component: ShowProductDetailsComponent },

  {
    path: 'showPruoductToUserComponent', component: ShowPruoductToUserComponent
  },

  {
    path:'orderConfirm', 
    component:OrderConfirmationComponent,
    canActivate:[authGuard],
    data:{
      roles:["User"]
    }

  },
  { path: 'myOrder', component:MyordersComponent ,
    canActivate: [authGuard],
      data: { roles: ['User'] }
    },

 { path: 'cart', component: ViewCartComponent,
  canActivate: [authGuard],
    data: { roles: ['User'] }
  },

 { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [authGuard],
    data: { roles: ['Admin'] }
  },
  {
    path: 'showAllOrder',
    component: ShowAllOrdersComponent,
    canActivate: [authGuard],
    data: { roles: ['Admin'] }
  },

  {
    path: 'user',
    component: UserComponent,
    canActivate: [authGuard],
    data: { roles: ['User'] }
  },

  {
    path: "addNewProduct", component: AddNewProductComponent,
    canActivate: [authGuard],
    data: { roles: ['Admin'] }


  },
  { path: 'login', component: LoginComponent },
  { path: 'forbidden', component: ForbiddenComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Add a default route
  { path: '**', redirectTo: '/home' } // Handle unknown routes
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
