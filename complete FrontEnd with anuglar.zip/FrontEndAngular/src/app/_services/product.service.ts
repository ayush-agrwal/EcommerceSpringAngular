import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../_model/product.model';
import { Observable } from 'rxjs';
import { OrderDetails } from '../_model/order-details.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(
    private httpClient:HttpClient
  ) { }
  private baseUrl = 'http://localhost:8080'; 

  public deliveredOrder(orderId){

    return this.httpClient.get<OrderDetails>("http://localhost:8080/deliveredOrder/"+orderId);
  }

  public getAllPlacedOrder(){

   return this.httpClient.get<OrderDetails>("http://localhost:8080/getAllOrderDetails");
  }

  public addProduct(product:FormData){
    return this.httpClient.post<Product>("http://localhost:8080/addNewProduct",product);
  }

  public getOrderByUser(){

    return this.httpClient.get<OrderDetails>("http://localhost:8080/getOrderDetails");
    
  }

  public deleteCartitem(cartId){

    return this.httpClient.delete("http://localhost:8080/deleteCartItem/"+cartId);
  }

  public getAllProduct(){

    return this.httpClient.get<Product[]>("http://localhost:8080/getAllProducts");
  }

  getProductById(productId: number): Observable<Product> {
    return this.httpClient.get<Product>(`${this.baseUrl}/getProductById/${productId}`);
  }

  public getProductDetails(isSingleCheckout,productId){

  return this.httpClient.get<Product[]>("http://localhost:8080/getProductDetails/"+isSingleCheckout+"/"+productId);
  }

  public placeOrder(orderDetails:OrderDetails,isCartCheckout){
    return this.httpClient.post("http://localhost:8080/placeOrder/"+isCartCheckout, orderDetails)
  }

  public addToCart(productId){

    return this.httpClient.get("http://localhost:8080/addToCart/"+productId);
  }

  public getCartDetails(){

    return this.httpClient.get("http://localhost:8080/getCartDetails");
  }
}
