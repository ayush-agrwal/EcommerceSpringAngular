import { Component,OnInit  } from '@angular/core';
import { ProductService } from '../_services/product.service';
import { error } from 'console';

@Component({
  selector: 'app-myorders',
  templateUrl: './myorders.component.html',
  styleUrl: './myorders.component.css'
})
export class MyordersComponent {

  userOrder:any=[];

  ngOnInit():void{

    this.showCart();
   }

  constructor(private productService:ProductService){

  }

  showCart(){

   this.productService.getOrderByUser().subscribe(
    (response)=>{
       console.log(response);
       this.userOrder=response;
    },
    (error)=>{
      console.log(error);
    }
   );
  
  }
}
