import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../_services/user.service';
import { response } from 'express';
import { error } from 'console';
import { UserAuthService } from '../_services/user-auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {





  constructor(private userService:UserService, private userAuthService: UserAuthService,
    private router:Router
  ){


  }

  login(loginForm:NgForm){

 // console.log(" i am called");

 //
 
 
 console.log(loginForm.value);

  

  this.userService.login(loginForm.value).subscribe({
    next: (response:any) => {

      console.log(response);
      console.log("JwtTOken="+response.jwtToken)
      console.log(response.user.role)
      this.userAuthService.setRoles(response.user.role);
      this.userAuthService.setToken(response.jwtToken);
     const role= response.user.role[0].roleName;
      if(role=="Admin"){
        this.router.navigate(['/admin'])

      }
      else{
        this.router.navigate(['/user'])
      }
    },
    error: (error) => {
      console.log(error);
    },
    complete: () => {
      console.log('Login request completed');
    }
  });
  }

  public registerNewUser() {
    //alert('I am working!!!');
    this.router.navigate(['/register']);
  }
}
