package com.youtube.jwt.services;
import com.youtube.jwt.configuration.JwtRequestFilter;
import com.youtube.jwt.dao.CartDao;
import com.youtube.jwt.dao.ProductDao;
import com.youtube.jwt.dao.UserDao;
import com.youtube.jwt.entity.Cart;
import com.youtube.jwt.entity.JwtRequest;
import com.youtube.jwt.entity.Product;
import com.youtube.jwt.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class ProductService {
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private UserDao userDao; 

	@Autowired
	private CartDao cartDao;
	public Product addNewProduct(Product product) {
		
		Product product2 =productDao.save(product);	
		return product2;
	}
	
	public List<Product> getAllProduct(){
		
		return (List)productDao.findAll();
	}
	
	public void deleteProduct(Integer productId) {
		 productDao.deleteById(productId);
	}
	public Product getProductById(Integer productId) {
		 Optional<Product> productOptional = productDao.findById(productId);
	        return productOptional.orElse(null);
	}
	
	public List<Product> getProductDetails(boolean isSingledProductCheckOut,
			Integer productId) {
		
		if(isSingledProductCheckOut && productId !=0) {
			// this true means user has only one in his cart 
			List<Product> list=new ArrayList<>();
				Product product=productDao.findById(productId).get();
			list.add(product);
			return list;
		}
		
		
		
		else {
			// this condition means that user has one more than product in the cart
			String  currentUser=JwtRequestFilter.CURRENT_USER;
			User user=userDao.findById(currentUser).get();
			List<Cart> carts=cartDao.findByUser(user);
			
			return carts.stream().map(x->x.getProduct()).collect(Collectors.toList());
			
			
		}
		
		
	}
}
