package com.youtube.jwt.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.youtube.jwt.entity.Cart;
import com.youtube.jwt.services.CartService;


@RestController
public class CartController {

	
	@Autowired
	private CartService cartSerive;
	
	
	@GetMapping({"/addToCart/{productId}"})
	public Cart addToCart(@PathVariable(name = "productId")Integer productId) {
		
		return cartSerive.addToCart(productId);
		
		
	}
	
	
	@DeleteMapping({"/deleteCartItem/{cartId}"})
	
	public void deleteCartItem(@PathVariable(name="cartId") Integer cartId) {
	
		cartSerive.deleteCartItem(cartId);
	}
	
	
	@GetMapping({"/getCartDetails"})
	public List<Cart> getCartDetails() {
		
		return cartSerive.getCartDetails();
		
	}
	
}
