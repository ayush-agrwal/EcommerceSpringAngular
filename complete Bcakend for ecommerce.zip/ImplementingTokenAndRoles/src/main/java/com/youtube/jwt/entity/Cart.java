package com.youtube.jwt.entity;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table

public class Cart {

	
	public Cart() {
		
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartId;
	@OneToOne
	private User user;
	@OneToOne
	private Product product;
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public Cart( Product product,User user) {
		super();
		this.user = user;
		this.product = product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	
	
	
}
