package com.youtube.jwt.services;

import java.nio.channels.NonWritableChannelException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.youtube.jwt.configuration.JwtRequestFilter;
import com.youtube.jwt.dao.CartDao;
import com.youtube.jwt.dao.ProductDao;
import com.youtube.jwt.dao.UserDao;
import com.youtube.jwt.entity.Cart;
import com.youtube.jwt.entity.Product;
import com.youtube.jwt.entity.User;
import  java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;


@Service
public class CartService {
	
	@Autowired
	private CartDao cartDao;
	
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private UserDao userDao;
	
	public void deleteCartItem(Integer cartId) {
		
		cartDao.deleteById(cartId);
	}
	public Cart addToCart(Integer productId) {
		Product product=productDao.findById(productId).get();
		
		String userName=JwtRequestFilter.CURRENT_USER;
		
		
		User user=null;
		
		if(userName!=null) {
			 user=userDao.findById(userName).get();
			
		}
		
		List<Cart> cartList=cartDao.findByUser(user);
		List<Cart> cartFilterredList=cartList.stream().filter(x-> x.getProduct().getProductId()==productId).collect(Collectors.toList());
		
		if(cartFilterredList.size()>0) {
			return null;
		}
		
		if(product !=null && user !=null ) {
			
			
			
			Cart cart = new Cart(product,user);
			
			return cartDao.save(cart);
			
			
		}
		
		return null;
		
	}
	
	public List<Cart> getCartDetails(){
		String userName=JwtRequestFilter.CURRENT_USER;
		
		User user=userDao.findById(userName).get();
		return cartDao.findByUser(user);
	}

}
