package com.youtube.jwt.entity;

import  java.util.*;
public class OrderInput {
	
	private String fullName;
	private String fullAddress;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getAlternateContactNumber() {
		return alternateContactNumber;
	}
	public void setAlternateContactNumber(String alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}
	public List<OrderProductQuantity> getOrderProductQuantity() {
		return orderProductQuantity;
	}
	public void setOrderProductQuantity(List<OrderProductQuantity> orderProductQuantity) {
		this.orderProductQuantity = orderProductQuantity;
	}
	private String contactNumber;
	private String alternateContactNumber;
	private List<OrderProductQuantity> orderProductQuantity;
	
}
