package com.youtube.jwt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.youtube.jwt.entity.OrderDetail;
import com.youtube.jwt.entity.OrderInput;
import com.youtube.jwt.services.OrderDetailService;


@RestController
public class OrdersDetailController {

	@Autowired
	private OrderDetailService orderDetailService;
	
	
	@PostMapping({"/placeOrder/{isCartCheckout}"})
	public void placeOrder(@PathVariable(name ="isCartCheckout") boolean isSingleProductCheckout
			,@RequestBody OrderInput orderInput) {
		
		orderDetailService.placeOrder(orderInput,isSingleProductCheckout);
	}
	
	@GetMapping({"/getOrderDetails"})
	public List<OrderDetail> getOrderDetails() {
		
		return orderDetailService.getOrderDetails();
	}
	
	@GetMapping({"/getAllOrderDetails"})
	public List<OrderDetail>  getAllPlacedOrder() {
		
		return orderDetailService.getAllPlacedorder();
	
	}
	@GetMapping({"/deliveredOrder/{orderId}"})
	public OrderDetail deliveredOrder(@PathVariable(name ="orderId") Integer orderId) {
		return orderDetailService.orderDelivered(orderId);
		
	}
}
