package com.youtube.jwt.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.youtube.jwt.entity.OrderDetail;
import com.youtube.jwt.entity.User;

public interface OrderDetailDao  extends CrudRepository<OrderDetail,Integer>{

	
	public List<OrderDetail> findByUser(User user);
	
	public OrderDetail findByOrderId(Integer orderId);
}
