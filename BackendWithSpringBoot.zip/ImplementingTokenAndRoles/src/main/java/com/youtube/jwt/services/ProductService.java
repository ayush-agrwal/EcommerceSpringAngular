package com.youtube.jwt.services;
import com.youtube.jwt.dao.ProductDao;
import com.youtube.jwt.entity.Product;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class ProductService {
	
	@Autowired
	private ProductDao productDao;
	

	public Product addNewProduct(Product product) {
		
		Product product2 =productDao.save(product);	
		return product2;
	}
	
	public List<Product> getAllProduct(){
		
		return (List)productDao.findAll();
	}
	
	public void deleteProduct(Integer productId) {
		 productDao.deleteById(productId);
	}
	public Product getProductById(Integer productId) {
		 Optional<Product> productOptional = productDao.findById(productId);
	        return productOptional.orElse(null);
	}
	
	public List<Product> getProductDetails(boolean isSingledProductCheckOut,
			Integer productId) {
		
		if(isSingledProductCheckOut) {
			// this true means user has only one in his cart 
			List<Product> list=new ArrayList<>();
				Product product=productDao.findById(productId).get();
			list.add(product);
			return list;
		}
		
		else {
			// this condition means that user has one more than product in the cart
		}
		
		return new ArrayList<>();
	}
}
