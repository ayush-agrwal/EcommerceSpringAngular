package com.youtube.jwt.dao;

import org.springframework.data.repository.CrudRepository;

import com.youtube.jwt.entity.OrderDetail;

public interface OrderDetailDao  extends CrudRepository<OrderDetail,Integer>{

}
