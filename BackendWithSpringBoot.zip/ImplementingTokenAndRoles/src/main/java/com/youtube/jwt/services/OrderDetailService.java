package com.youtube.jwt.services;

import org.hibernate.engine.query.spi.sql.NativeSQLQueryCollectionReturn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.youtube.jwt.configuration.JwtRequestFilter;
import com.youtube.jwt.dao.OrderDetailDao;
import com.youtube.jwt.dao.ProductDao;
import com.youtube.jwt.dao.UserDao;
import com.youtube.jwt.entity.OrderDetail;
import com.youtube.jwt.entity.OrderInput;
import com.youtube.jwt.entity.OrderProductQuantity;
import com.youtube.jwt.entity.Product;
import com.youtube.jwt.entity.User;

import java.util.*;
@Service
public class OrderDetailService {
	
	private static final String ORDER_PLACED="Placed";
	@Autowired
	private OrderDetailDao orderDetailDao;
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private UserDao userDao;

	private Product product;
	public void placeOrder(OrderInput orderInput) {
		List<OrderProductQuantity> productQuantityList =orderInput.getOrderProductQuantity();
	
		for(OrderProductQuantity o:productQuantityList) {
			 product=productDao.findById(o.getProductId()).get();
			 String currentUser=JwtRequestFilter.CURRENT_USER;
			 User user=userDao.findById(currentUser).get();
			 
			OrderDetail orderDetail=new OrderDetail(
					orderInput.getFullName(),
					orderInput.getFullAddress(),
					orderInput.getContactNumber(),
					orderInput.getAlternateContactNumber(),
					ORDER_PLACED,
					product.getProductActualPrice()*o.getQuantity(),
					product,
					
					user
					);
			
			orderDetailDao.save(orderDetail);
		}
	}
	
}
