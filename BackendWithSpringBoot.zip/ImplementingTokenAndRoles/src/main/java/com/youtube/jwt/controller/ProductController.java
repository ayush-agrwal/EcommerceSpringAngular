package com.youtube.jwt.controller;



import java.util.List;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;

import com.youtube.jwt.entity.ImageModel;
import com.youtube.jwt.entity.Product;
import com.youtube.jwt.services.ProductService;


@RestController
public class ProductController {

	@Autowired
	private ProductService productService;
	
	
	@GetMapping({"/getAllProducts"})
	public List<Product> getAllProduct(){
		
		return productService.getAllProduct();
	}
	
	
	
	@PreAuthorize("hasRole('Admin')")
	@PostMapping(value={"/addNewProduct"},consumes= {MediaType.MULTIPART_FORM_DATA_VALUE})
	public Product addNewProduct(@RequestPart("product") Product product,
			@RequestPart ("imageFile") MultipartFile[] file) {
		
		
		
		try {
			Set<ImageModel> images=uploadImage(file);
			product.setProductImages(images);
			return productService.addNewProduct(product);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
		
		
	}
	
	public Set<ImageModel> uploadImage(MultipartFile[] file) throws IOException{
		
		Set<ImageModel> imageModels=new HashSet<>();
		
		for(MultipartFile f:file) {
			ImageModel imageModel=new ImageModel(
					
					f.getOriginalFilename(),
					f.getContentType(),
					f.getBytes()
					
					
					);
			imageModels.add(imageModel);
		}
		
		return imageModels;
		
	}
	
	@DeleteMapping({"/deleteProductDetails/{productId}"})
	public void deleteProductDetails(@PathVariable("productId") Integer productId) {
		
		productService.deleteProduct(productId);
		System.out.println("Successfully deleted");
	}
	
	@GetMapping({"/getProductById/{productId}"})
	public Product getProductById(@PathVariable("productId") Integer productId) {
		return productService.getProductById(productId);
				
	}
	
	
	@PreAuthorize("hasRole('User')")
	
	@GetMapping({"/getProductDetails/{isSingleProductCheckout}/{productId}"})
	
	public List<Product> getProductDetails(@PathVariable(name="isSingleProductCheckout") boolean isSingleProductCheckout,
			@PathVariable(name="productId") Integer productId
			) {
		
		return productService.getProductDetails(isSingleProductCheckout, productId);
		
		
	}
	
	
}
